import numpy as np

x0, y0 = (8192, 8192)

def restore_ground(mdl, comp_handle):
    pass