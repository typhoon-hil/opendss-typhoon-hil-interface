from ..gui_scripts import general_objects as obj
